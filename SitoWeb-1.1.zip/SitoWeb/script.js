function mostra_mail() {
    document.write("mail: <a href=\"mailto:liceopeanopellico&#64;gmail&#46;com\">liceopeanopellico&#64;gmail&#46;com</a> - pec: <a href=\"mailto:cnps02000n&#64;pec&#46;istruzione&#46;it\">cnps02000n&#64;pec&#46;istruzione&#46;it</a>");
}